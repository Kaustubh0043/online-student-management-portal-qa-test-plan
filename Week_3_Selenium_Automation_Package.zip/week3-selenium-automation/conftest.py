"""Browser setup, teardown, and failure evidence for the simulated portal."""
import os
from pathlib import Path

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


@pytest.fixture
def base_url() -> str:
    return os.getenv("PORTAL_BASE_URL", "http://localhost:8000").rstrip("/")


@pytest.fixture
def driver(request):
    options = Options()
    if os.getenv("HEADLESS", "0").lower() in {"1", "true", "yes"}:
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1440,1000")
    options.add_argument("--disable-notifications")
    browser = webdriver.Chrome(options=options)
    browser.set_page_load_timeout(20)
    browser.implicitly_wait(0)  # This suite uses explicit waits only.
    yield browser
    report = getattr(request.node, "rep_call", None)
    if report and report.failed:
        evidence_dir = Path("artifacts")
        evidence_dir.mkdir(exist_ok=True)
        safe_name = request.node.name.replace("/", "_")
        browser.save_screenshot(str(evidence_dir / f"{safe_name}.png"))
    browser.quit()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    setattr(item, f"rep_{report.when}", report)
