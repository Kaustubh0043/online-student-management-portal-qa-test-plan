"""End-to-end workflows for the hypothetical Online Student Management Portal."""
from uuid import uuid4

from selenium.webdriver.common.by import By

from portal_pages import DashboardPage, LoginPage, PortalPage, StudentsPage

TEST_EMAIL = "qa.student@example.test"
TEST_PASSWORD = "Password123!"


def login(driver, base_url):
    page = LoginPage(driver, base_url)
    page.load()
    page.submit(TEST_EMAIL, TEST_PASSWORD)
    return page


def test_valid_login_opens_dashboard(driver, base_url):
    login(driver, base_url)
    assert "Dashboard" in DashboardPage(driver, base_url).heading().text


def test_invalid_login_shows_error(driver, base_url):
    page = LoginPage(driver, base_url)
    page.load()
    page.submit("unknown@example.test", "incorrect-password")
    assert page.visible("login-error").is_displayed()
    assert "/dashboard" not in driver.current_url


def test_registration_accepts_new_student(driver, base_url):
    email = f"qa+{uuid4().hex[:10]}@example.test"
    page = PortalPage(driver, base_url)
    page.open("/register")
    page.visible("full-name").send_keys("QA Sample Student")
    driver.find_element(By.ID, "register-email").send_keys(email)
    driver.find_element(By.ID, "register-password").send_keys(TEST_PASSWORD)
    page.clickable("register-submit").click()
    assert page.visible("registration-success").is_displayed()


def test_dashboard_navigation_opens_profile(driver, base_url):
    login(driver, base_url)
    page = PortalPage(driver, base_url)
    page.clickable("nav-profile").click()
    assert "Profile" in page.visible("profile-title").text


def test_student_search_returns_matching_record(driver, base_url):
    login(driver, base_url)
    page = StudentsPage(driver, base_url)
    page.load()
    result = page.search("Aarav Sharma")
    assert "Aarav Sharma" in result.text


def test_student_record_create_update_delete(driver, base_url):
    login(driver, base_url)
    page = StudentsPage(driver, base_url)
    page.load()
    email = f"qa+{uuid4().hex[:10]}@example.test"
    assert page.create_student("QA CRUD Student", email).is_displayed()
    assert page.edit_first_student("QA CRUD Student Updated").is_displayed()
    results = page.search(email)
    assert "QA CRUD Student Updated" in results.text
    assert page.delete_first_student().is_displayed()


def test_logout_returns_to_login(driver, base_url):
    login(driver, base_url)
    page = PortalPage(driver, base_url)
    page.clickable("nav-logout").click()
    assert page.visible("login-submit").is_displayed()
    assert "/login" in driver.current_url
