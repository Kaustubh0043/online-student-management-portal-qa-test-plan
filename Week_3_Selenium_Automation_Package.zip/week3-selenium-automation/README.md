# Week 3 Automated Test Script Development

**Project:** Online Student Management Portal  
**Report date:** 6 September 2026  
**Internship period:** 21 August 2026 to 2 October 2026  
**Framework:** Python, Selenium WebDriver 4, and pytest

## Purpose and simulation notice

This package contains maintainable browser automation examples for six portal workflows: valid login, invalid login/error handling, student registration, dashboard navigation, student search, student record CRUD, and logout (seven scenarios, with CRUD treated as one end-to-end workflow). The application is hypothetical. No running portal, production account, or real student data was supplied, so the suite has not been executed against an application. The URLs, element IDs, and outcomes below are explicit assumptions to be confirmed against a real build before execution. Do not interpret these tests as verified findings.

## Simulated application contract

Base URL defaults to `http://localhost:8000`; override it with `PORTAL_BASE_URL`.

| Page / function | Assumed URL | Expected element IDs |
|---|---|---|
| Login | `/login` | `email`, `password`, `login-submit`, `login-error` |
| Registration | `/register` | `full-name`, `register-email`, `register-password`, `register-submit`, `registration-success` |
| Dashboard | `/dashboard` | `dashboard-title`, `nav-profile`, `nav-students`, `nav-logout` |
| Profile | `/profile` | `profile-title` |
| Students | `/students` | `student-search`, `student-search-submit`, `student-results`, `student-create`, `student-name`, `student-email`, `student-save`, `student-edit`, `student-delete`, `student-success`, `student-empty` |

Assumed test account is `qa.student@example.test` / `Password123!`. The simulated backend should reset or isolate data between runs, provide a test-only environment, and expose accessible confirmation messages matching these IDs.

## Requirements and run instructions

1. Install Python 3.10 or newer and a current Chrome browser.
2. In this directory create and activate a virtual environment, then run `pip install -r requirements.txt`.
3. Start the compatible simulated portal. By default the scripts target `http://localhost:8000`; set `PORTAL_BASE_URL` when needed.
4. Run `pytest -v`. Set `HEADLESS=1` to run Chrome without a visible window. On first run Selenium Manager may need network access to locate a compatible driver.

The suite uses explicit waits for states rather than fixed sleeps. Pytest fixtures create a fresh browser for each test and always close it. A screenshot is saved in `artifacts/` when a test fails. Never put real student information or production credentials in environment variables or test data.

## Scenarios and acceptance checks

| Test | Workflow | Pass condition |
|---|---|---|
| `test_valid_login_opens_dashboard` | Login | Dashboard heading appears after valid credentials |
| `test_invalid_login_shows_error` | Error handling | Error message appears and dashboard is not opened |
| `test_registration_accepts_new_student` | Form submission | Unique account is accepted and success message appears |
| `test_dashboard_navigation_opens_profile` | Navigation | Profile page heading appears |
| `test_student_search_returns_matching_record` | Search | Result list contains the searched student |
| `test_student_record_create_update_delete` | CRUD | Created record can be edited and then removed |
| `test_logout_returns_to_login` | Logout | Login form appears and protected dashboard is no longer shown |

## Maintainability and known limits

Locators and reusable interactions are centralized in `portal_pages.py`; test methods contain workflow assertions. Tests use unique synthetic emails to reduce data collisions. Update selectors in one place if the application markup differs. Browser automation alone does not replace API, accessibility, compatibility, performance, or security testing. Authentication, registration policy, validation text, and delete confirmation behavior are assumptions that must be reviewed with the product owner. The code is a training example, not evidence of completed execution.

## References

- Selenium WebDriver: https://www.selenium.dev/documentation/webdriver/
- Selenium waiting strategies: https://www.selenium.dev/documentation/webdriver/waits/
- Selenium Page Object Models: https://www.selenium.dev/documentation/test_practices/encouraged/page_object_models/
