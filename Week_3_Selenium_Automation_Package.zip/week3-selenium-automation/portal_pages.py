"""Page objects for the documented, hypothetical student portal DOM."""
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


class PortalPage:
    def __init__(self, driver, base_url, timeout=10):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, timeout)

    def open(self, path):
        self.driver.get(f"{self.base_url}{path}")

    def visible(self, element_id):
        return self.wait.until(EC.visibility_of_element_located((By.ID, element_id)))

    def clickable(self, element_id):
        return self.wait.until(EC.element_to_be_clickable((By.ID, element_id)))


class LoginPage(PortalPage):
    def load(self):
        self.open("/login")

    def submit(self, email, password):
        self.visible("email").clear()
        self.driver.find_element(By.ID, "email").send_keys(email)
        self.driver.find_element(By.ID, "password").clear()
        self.driver.find_element(By.ID, "password").send_keys(password)
        self.clickable("login-submit").click()


class DashboardPage(PortalPage):
    def heading(self):
        return self.visible("dashboard-title")


class StudentsPage(PortalPage):
    def load(self):
        self.open("/students")

    def search(self, query):
        field = self.visible("student-search")
        field.clear()
        field.send_keys(query)
        self.clickable("student-search-submit").click()
        return self.visible("student-results")

    def create_student(self, name, email):
        self.clickable("student-create").click()
        self.visible("student-name").send_keys(name)
        self.driver.find_element(By.ID, "student-email").send_keys(email)
        self.clickable("student-save").click()
        return self.visible("student-success")

    def edit_first_student(self, name):
        self.clickable("student-edit").click()
        field = self.visible("student-name")
        field.clear()
        field.send_keys(name)
        self.clickable("student-save").click()
        return self.visible("student-success")

    def delete_first_student(self):
        self.clickable("student-delete").click()
        # Assumption: delete is immediate in the training app. If a confirmation
        # dialog is required, add its documented confirmation locator here.
        return self.visible("student-empty")
